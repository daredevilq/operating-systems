#pragma once
  extern int sumuj(int *tab, int n);
  extern double srednia(int *tab, int n);
